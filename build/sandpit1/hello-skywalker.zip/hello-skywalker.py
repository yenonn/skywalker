def main():
    print("hello world skywalker")
