from logger import Logger
import os, json
from importlib import import_module


def load_module(handler):
    """Loading the function caller"""
    if handler:
        pathname = ".".join(handler.split(".")[:-1])
        name = handler.split(".")[-1]
        module = import_module(pathname)
        caller = getattr(module, name)
        return caller


def load_config(config="/app/config.json"):
    """Loading the modules from config.json"""
    func_config = {}
    if os.path.isfile(config):
        with open(config) as jsonfile:
            func_config = json.load(jsonfile)
    else:
        raise Exception("No /app/config.json found. Module loading is not possible.")
    return func_config


def main():
    func_config = load_config()
    executor_name = func_config.get("executor")
    print(f"Executor: {executor_name}")
    executor_cls = load_module(executor_name)
    executor_obj = executor_cls(func_config)
    executor_obj.execute()


class BaseExecutor:
    def __init__(self):
        self.logger = Logger.logger_config()

    def execute(self):
        raise NotImplementedError("Please implement this method")


class DefaultExecutor(BaseExecutor):
    def __init__(self, config):
        self.func_config = config

    def execute(self):
        caller = load_module(self.func_config.get("handler"))
        print(f"Executing function: {self.func_config.get('name')}")
        caller()


class EsToPdExecutor(BaseExecutor):
    def execute(self):
        pass


if __name__ == "__main__":
    main()
