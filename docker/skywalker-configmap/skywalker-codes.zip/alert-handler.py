class BaseAlertHandler(object):
    pass


class PagerDutyAlertHandler(BaseAlertHandler):
    pass


class SlackAlertHandler(BaseAlertHandler):
    pass
