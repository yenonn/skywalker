class FakeElasticsearch(object):
    def __init__(self):
        print("this is a elasticsearch calls")

    def fake_task(self):
        print("testing 123")
