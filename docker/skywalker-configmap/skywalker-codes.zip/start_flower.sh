#
 celery -A job_controller.app flower --address=127.0.0.1 --port=5566

