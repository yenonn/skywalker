from logger import LoggerFactory


def main():
    logger = LoggerFactory().Logger
    logger.info("workflow skywalker")
