from logger import LoggerFactory


def main(**kwargs):
    logger = LoggerFactory().Logger
    logger.info("workflow skywalker")
